#!/usr/bin/env python
""" MegaPi Controller ROS Wrapper"""
import rospy
import time
import numpy as np
import math

from sensor_msgs.msg import Joy
from mpi_control import MegaPiController
from std_msgs.msg import String
from geometry_msgs.msg import PoseArray
from rb5_control.msg import *



class MegaPiControllerNode:
    def __init__(self, verbose=True, debug=False):
        self.mpi_ctrl = MegaPiController(port='/dev/ttyUSB0', verbose=verbose)
        self.v_max_default_straight = 100
        self.v_max_default_slide = 100
        self.v_max_default_rotate = 50
        self.reset_v_max()
        self.verbose = verbose
        self.debug = debug
        self.state = "run"
    

    def reset_v_max(self):
        self.v_max_straight = self.v_max_default_straight
        self.v_max_slide = self.v_max_default_slide
        self.v_max_rotate = self.v_max_default_rotate

    def to_4dmatrix(self, quaternion, trans):

        rotation = self.quaternion_rotation_matrix(quaternion)
        t = np.array([trans[0], trans[1], trans[2]]).reshape(3,1)
        padding = np.array([[0,0,0,1]])
        
        matrix = np.concatenate((rotation, t), axis=1)
        matrix = np.concatenate((matrix, padding), axis=0)
        
        return matrix

    def tag_matrix(self, x, y, z, trans):
        a = x * math.pi / 180
        b = y * math.pi / 180
        c = z * math.pi / 180
        rx = np.array([[1,          0 ,           0],
                       [0,          math.cos(a),  -1* math.sin(a)],
                       [0,          math.sin(a),  math.cos(a)]])
        ry = np.array([[math.cos(b),0 , math.sin(b)],
                        [0,          1,            0],
                        [-1* math.sin(b),    0,  math.cos(b)]])
        rz = np.array([[math.cos(c),  -1*math.sin(c),  0],
                       [math.sin(c),  math.cos(c),  0],
                       [0,            0,            1]])
                                                       
        
        rotation =  rx.dot(ry).dot(rz)
        t = np.array([trans[0], trans[1], trans[2]]).reshape(3,1)
        padding = np.array([[0,0,0,1]])
        
        matrix = np.concatenate((rotation, t), axis=1)
        matrix = np.concatenate((matrix, padding), axis=0)
        
        return matrix

    def quaternion_rotation_matrix(self,Q):

        q0 = Q[0]
        q1 = Q[1]
        q2 = Q[2]
        q3 = Q[3]

        r00 = 2 * (q0 * q0 + q1 * q1) - 1
        r01 = 2 * (q1 * q2 - q0 * q3)
        r02 = 2 * (q1 * q3 + q0 * q2)
        
        r10 = 2 * (q1 * q2 + q0 * q3)
        r11 = 2 * (q0 * q0 + q2 * q2) - 1
        r12 = 2 * (q2 * q3 - q0 * q1)
        
        r20 = 2 * (q1 * q3 - q0 * q2)
        r21 = 2 * (q2 * q3 + q0 * q1)
        r22 = 2 * (q0 * q0 + q3 * q3) - 1
        
        rot_matrix = np.array([[r00, r01, r02],
                               [r10, r11, r12],
                               [r20, r21, r22]])

        return rot_matrix

    def get_robot_pose(self, r_w):

        robot_loc = r_w[:3,3].reshape(3,)
        
        r_v = np.array([0,0,1,1]).reshape(4,1)
        w_v = (r_w.dot(r_v))[:3,:].reshape(3,)

        direction = (w_v - robot_loc)[:2]

        angle = np.arctan2(direction[1], direction[0])

        return robot_loc[:2], angle

    def modify(self, distance, alpha, beta):
        kp = 1
        ka = 1
        kb = 1
        
        v = kp*distance
        w = ka*alpha + kb*beta
        
        return v, w

    def to_target(self, loc, angle, target):
        dx = target[0] - loc[0]
        dy = target[1] - loc[1]
        
        distance = math.sqrt(dx*dx + dy*dy)
        alpha = np.arctan2(dy, dx) - angle
        beta = -1 * angle - alpha - target[2]
        v, w = self.modify(distance, alpha, beta)
        
        return v, w

    def fourwheel(self, vx, vy, w):
        r = 0.02
        length = 1
        w1 = -1 * (1/r) * (vx - vy - length*w)
        w2 = (1/r) * (vx + vy + length*w)
        w3 = -1 * (1/r) * (vx + vy - length*w)
        w4 = (1/r) * (vx - vy + length*w)
        self.mpi_ctrl.setFourMotors(w1, w2, w3, w4)

    def detection_callback(self, detection_msg):
        print("start")
        # when a pose of a tag is detected
        if len(detection_msg.detections) == 1:
            id = detection_msg.detections[0].id
            pos = detection_msg.detections[0].pose.position
            ori = detection_msg.detections[0].pose.orientation
            print("Detected a tag:", id)

            trans = [pos.x, pos.y, pos.z]
            q = [ori.w, ori.x, ori.y, ori.z]
            

            t_r = self.to_4dmatrix(q, trans)             # tag pose in robot
            t_w = self.tag_matrix(-90, 90, 0, [1.5, 0, 0]) # tag pose in world

            r_w = t_w.dot(np.linalg.inv(t_r))            # robot pose in world


            loc,angle = self.get_robot_pose(r_w)
            target = [1,0,0]
            v, w = self.to_target(loc, angle, target)

            self.fourwheel(v, 0, w)

            print("trans is:", trans)
            print("quaternion(w,x,y,z) is:", q)
            print("tag in robot is: ", t_r)
            print("tag in world is: ", t_w)
            print("robot in world is: ", r_w)
            print("robot location(x,y): ", loc)
            print("robot orientation: ", angle)
            print("target is: ", target)
            print("v is:", v)
            print("w is:", w)

        else:
            self.fourwheel(0,0,0)



        print("end")
        

    def joy_callback(self, joy_cmd):
        if self.debug:
            print('buttons:', joy_cmd.buttons)
            print('axes:', [round(axe,2) for axe in joy_cmd.axes])
        if joy_cmd.buttons[4] == 1:
            if self.state == "run":
                self.state = "stop"
            elif self.state == "stop":
                self.state = "run"
        if self.state == "stop":
            print('Vehicle in the stop state.')
            return
        
        if joy_cmd.buttons[5] == 1:
            print('Reset max speed')
            self.reset_v_max()

        v_straight = 0
        v_slide = 0
        v_rotate = 0

        v_slide = self.v_max_slide * joy_cmd.axes[0]
        v_straight = self.v_max_straight * joy_cmd.axes[1]
        v_rotate = self.v_max_rotate * joy_cmd.axes[2]

        if joy_cmd.axes[4] > 0:
            self.v_max_slide -= 10
        elif joy_cmd.axes[4] < 0:
            self.v_max_slide += 10
        if joy_cmd.axes[5] > 0:
            self.v_max_straight += 10
        elif joy_cmd.axes[5] < 0:
            self.v_max_straight -= 10
        if joy_cmd.buttons[1] == 1:
            self.v_max_rotate += 10
        elif joy_cmd.buttons[3] == 1:
            self.v_max_rotate -= 10

        if self.verbose:
            print('state: ' + self.state +
                  ' v_straight: ' + repr(int(round(v_straight, 2))) + '/' + repr(self.v_max_straight) +
                  ' v_slide: '+ repr(int(round(v_slide, 2))) + '/' + repr(self.v_max_slide) +
                  ' v_rotate: ' + repr(int(round(v_rotate, 2))) + '/' + repr(self.v_max_rotate))

        if abs(joy_cmd.axes[2]) <= 0.1:
            if abs(joy_cmd.axes[0]) <= 0.1 and abs(joy_cmd.axes[1]) <= 0.1:
                self.mpi_ctrl.carStop()
            elif abs(joy_cmd.axes[0]) <= 0.1:
                self.mpi_ctrl.carStraight(v_straight)
            elif abs(joy_cmd.axes[1]) <= 0.1:
                self.mpi_ctrl.carSlide(v_slide)
            else:
                self.mpi_ctrl.carMixed(v_straight, 0, v_slide)
        else:
            if abs(joy_cmd.axes[0]) <= 0.1 and abs(joy_cmd.axes[1]) <= 0.1:
                self.mpi_ctrl.carRotate(v_rotate)
            else:
                self.mpi_ctrl.carMixed(v_straight, v_rotate, v_slide)
        

if __name__ == "__main__":
    mpi_ctrl_node = MegaPiControllerNode()
    rospy.init_node('megapi_controller')
    #rospy.Subscriber('/joy', Joy, mpi_ctrl_node.joy_callback, queue_size=1) 
    
    rospy.Subscriber('/apriltag_detection_array', AprilTagDetectionArray, mpi_ctrl_node.detection_callback, queue_size=1)
    rospy.spin()
