#ifndef RB5_CONTROL_H
#define RB5_CONTROL_H
#include <serial/serial.h>

class Rb5Control{
  public:
    Rb5Control();
    ~Rb5Control();
  
};
#endif // RB5_CONTROL_H
